<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <title>Cadastro - Sistema JS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">

</head>

<body class="bg-light d-flex align-items-center" style="height: 100vh;">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-4 card p-4 shadow">
                <h3 class="text-center mb-4">Criar Conta</h3>
                <form id="formCadastro">
                    <div class="mb-3">
                        <label class="form-label">Nome de Usuário</label>
                        <input type="text" id="nome" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Senha</label>
                        <input type="password" id="senha" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Confirmar Senha</label>
                        <input type="password" id="confirmaSenha" class="form-control" required>
                    </div>
                    <div class="d-grid gap-2">
                        <button type="submit" class="btn btn-success">Cadastrar</button>
                        <button type="reset" class="btn btn-outline-secondary">Limpar</button>
                    </div>
                </form>
                <div class="text-center mt-3">
                    <a href="login.php">Já tenho conta</a>
                </div>
            </div>
        </div>
    </div>

    <script>
        document.getElementById('formCadastro').addEventListener('submit', function(e) {
            e.preventDefault();
            const nome = document.getElementById('nome').value;
            const senha = document.getElementById('senha').value;
            const confirma = document.getElementById('confirmaSenha').value;

            if (senha !== confirma) {
                alert("As senhas não coincidem!");
                return;
            }

            // Salva no localStorage (chave: nome, valor: senha)
            localStorage.setItem(nome, senha);
            alert("Cadastro realizado com sucesso!");
            window.location.href = "login.php";
        });
    </script>
</body>

</html>