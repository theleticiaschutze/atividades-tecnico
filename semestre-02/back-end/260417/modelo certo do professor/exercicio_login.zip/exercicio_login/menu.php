<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <title>Menu Principal</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">

</head>

<body>
    <nav class="navbar navbar-dark bg-dark mb-4">
        <div class="container-fluid">
            <span class="navbar-brand">Sistema Interno</span>
            <button class="btn btn-danger btn-sm" onclick="logout()">Sair</button>
        </div>
    </nav>

    <div class="container text-center">
        <h2 id="boasVindas">Bem-vindo!</h2>
        <p>Você está na área logada do sistema.</p>
    </div>

    <script>
        // Verifica se há alguém logado no sessionStorage
        const usuario = sessionStorage.getItem('usuarioLogado');
        if (!usuario) {
            window.location.href = "login.php";
        } else {
            document.getElementById('boasVindas').innerText = "Olá, " + usuario + "!";
        }

        function logout() {
            sessionStorage.removeItem('usuarioLogado');
            window.location.href = "login.php";
        }
    </script>
</body>

</html>