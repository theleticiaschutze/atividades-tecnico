<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <title>Login - Sistema JS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">

</head>

<body class="bg-light d-flex align-items-center" style="height: 100vh;">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-4 card p-4 shadow">
                <h3 class="text-center mb-4">Login</h3>
                <form id="formLogin">
                    <div class="mb-3">
                        <label class="form-label">Usuário</label>
                        <input type="text" id="loginNome" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Senha</label>
                        <input type="password" id="loginSenha" class="form-control" required>
                    </div>
                    <div class="d-grid gap-2">
                        <button type="submit" class="btn btn-primary">Entrar</button>
                        <a href="cadastrar.php" class="btn btn-outline-primary">Cadastrar</a>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
        document.getElementById('formLogin').addEventListener('submit', function(e) {
            e.preventDefault();
            const nome = document.getElementById('loginNome').value;
            const senha = document.getElementById('loginSenha').value;

            const senhaSalva = localStorage.getItem(nome);

            if (senhaSalva && senhaSalva === senha) {
                // Simula uma sessão simples
                sessionStorage.setItem('usuarioLogado', nome);
                window.location.href = "menu.php";
            } else {
                alert("Usuário ou senha incorretos!");
            }
        });
    </script>
</body>

</html>